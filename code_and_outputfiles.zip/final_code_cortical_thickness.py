# -*- coding: utf-8 -*-

import matplotlib
from matplotlib import pylab as plt
import nibabel as nib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skimage.io import imread, imshow
from skimage.color import rgb2gray
from skimage.morphology import (erosion, dilation, closing, opening,
                                area_closing, area_opening)
from skimage.measure import label
import nibabel as nib
from nilearn import plotting

img_data1 = nib.load('raw_t1_subject_02.nii.gz').get_fdata()
img1=nib.load('raw_t1_subject_02.nii.gz')


plt.imshow(img1.get_fdata()[:,120,:])
plotting.plot_anat('raw_t1_subject_02.nii.gz', title="T1", vmax=150)
header = img1.header
print(header)


import dipy.denoise.nlmeans as nimeans
den_img_data1 = nimeans.nlmeans(img_data1,8)

plt.figure(figsize=(10,10))
plt.subplot (1,3,1); plt. imshow(img_data1[:, 120, :]); plt.title(' swi original')
plt.subplot (1,3,2); plt.imshow(den_img_data1[:, 120, :]); plt.title('swi denoised')
plt.subplot (1,3,3); plt.imshow(img_data1[:, 120, :]-den_img_data1[:, 120, :]); plt.title('swi method noise ')

plt.subplots_adjust(left=0.3,
                    bottom=0.3, 
                    right=2.0, 
                    top=0.9, 
                    wspace=0.3, 
                    hspace=0.3)
plt.show()


original_image = den_img_data1.copy()

import cv2
def KNN_segmentation(img,K):
    original_image = img
    original_image = original_image.astype('uint8')
    vectorized = original_image.reshape((-1))
    vectorized = np.float32(vectorized)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    attempts=50
    ret,label,center=cv2.kmeans(vectorized,K,None,criteria,attempts,cv2.KMEANS_PP_CENTERS)
    center = np.uint8(center)
    res = center[label.flatten()]
    result_image = res.reshape((original_image.shape))
    print(np.unique(result_image))
    return result_image



i = 120
K=3
white = KNN_segmentation(original_image,5)
image1 = np.where(white !=102, 0, white)
figure_size = 10
plt.figure(figsize=(figure_size,figure_size))
plt.subplot(1,2,1),plt.imshow(original_image[:,i,:])
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(1,2,2),plt.imshow(image1[:,i,:],vmax=30)
plt.title('Segmented Image when K = %i' % K), plt.xticks([]), plt.yticks([])
plt.show()

from skimage.morphology import square
from skimage import morphology
import skimage
o = image1.copy()
mask_dilation = np.zeros((5,5,5),dtype=int)
mask_dilation[mask_dilation == 0] =1
dil = skimage.morphology.dilation(o,mask_dilation)

# Added this library for making code robust 
# Custom creation of brain mask code is also included but it is not robust as each image differs and should be tuning according to the image
import nipype.interfaces.fsl as fsl
mybet = fsl.BET(in_file='raw_t1_subject_02.nii.gz', out_file='brain_extracted.nii')
result = mybet.run()
final_skull_removed = nib.load('brain_extracted.nii.gz').get_fdata()
final_skull_removed= nimeans.nlmeans(final_skull_removed,8)


i=120
plt.figure(figsize=(10,10))
plt.subplot(1,3,1);plt.imshow(final_skull_removed[:,i,:]);plt.title("mask")
plt.subplot(1,3,2);plt.imshow(final_skull_removed[i,:,:]);plt.title("side mask")
plt.show()

i = 120
K=3
result_image = KNN_segmentation(final_skull_removed,5)
image1 = np.where(result_image !=104, 0, result_image)
figure_size = 10
plt.figure(figsize=(figure_size,figure_size))
plt.subplot(1,2,1),plt.imshow(final_skull_removed[:,i,:])
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(1,2,2),plt.imshow(image1[:,i,:],vmax=30)
plt.title('Segmented Image when K = %i' % K), plt.xticks([]), plt.yticks([])
plt.show()

i = 120
K=3
image2 = np.where(result_image !=56, 0, result_image)
figure_size = 10
plt.figure(figsize=(figure_size,figure_size))
plt.subplot(1,2,1),plt.imshow(final_skull_removed[:,i,:])
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(1,2,2),plt.imshow(image2[:,i,:],vmax=30)
plt.title('Segmented Image when K = %i' % K), plt.xticks([]), plt.yticks([])
plt.show()

grey_matter_img = nib.Nifti1Image(image2, img1.affine)
white_matter_img = nib.Nifti1Image(image1, img1.affine)
nib.save(grey_matter_img, 'greymatter.nii')
nib.save(white_matter_img , 'whitematter.nii')


# Phase 2 

import matplotlib
from matplotlib import pylab as plt
import nibabel as nib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skimage.io import imread, imshow
from skimage.color import rgb2gray
from skimage.morphology import (erosion, dilation, closing, opening,
                                area_closing, area_opening)
from skimage.measure import label, regionprops, regionprops_table
from nipype.interfaces.ants.segmentation import BrainExtraction
import nibabel as nib
from nilearn import plotting

img_grey_mask1 = nib.load('greymatter.nii').get_fdata()
img_grey_mask = nib.load('greymatter.nii')
img_white_mask1 = nib.load('whitematter.nii').get_fdata()
img_white_mask = nib.load('whitematter.nii')


# %matplotlib inline
figure_size = 10
i=120
plt.figure(figsize=(figure_size,figure_size))
plt.subplot(1,2,1),plt.imshow(img_grey_mask1[:,i,:])
plt.title('grey mask'), plt.xticks([]), plt.yticks([])
plt.subplot(1,2,2),plt.imshow(img_white_mask1[:,i,:],vmax=30)
plt.title('white mask'), plt.xticks([]), plt.yticks([])
plt.show()

def dilation_img(img,iters):
    dil=img
    for i in range(iters):
        dil = dilation(dil)
    return dil

figure_size = 5
plt.figure(figsize=(figure_size,figure_size))
dilated_white_mask = dilation_img(img_white_mask1,1)
contour_white_mask = dilated_white_mask-img_white_mask1
plt.imshow(contour_white_mask[:,120,:])

grey_mask = img_grey_mask1
white_mask = img_white_mask1
contour_white_mask = contour_white_mask

grey_mask = np.array(np.where(grey_mask==56., 1., grey_mask),dtype='uint8')
white_mask  = np.array(np.where(white_mask ==104., 1., white_mask ),dtype='uint8')
contour_white_mask = np.array(np.where(contour_white_mask==104., 1., contour_white_mask),dtype='uint8')

print(np.unique(grey_mask))
print(np.unique(white_mask ))
print(np.unique(contour_white_mask))

locations_white_contour_mask = []
for x,x1 in enumerate(contour_white_mask):
    for y,y1 in enumerate(x1):
        for z,z1 in enumerate(x1):
            if contour_white_mask[x][y][z]==1:
                locations_white_contour_mask.append([x,y,z])

locations_grey_mask = []
for x,x1 in enumerate(grey_mask):
    for y,y1 in enumerate(x1):
        for z,z1 in enumerate(x1):
            if grey_mask[x][y][z]==1:
                locations_grey_mask.append([x,y,z])

# %matplotlib inline

x = np.array([locations_grey_mask[i][0] for i in range(len(locations_grey_mask))])
y= np.array([locations_grey_mask[i][1] for i in range(len(locations_grey_mask))])
z= np.array([locations_grey_mask[i][2] for i in range(len(locations_grey_mask))])


P = (x1, y1, z1)
def distance_3d(x, y, z, x0, y0, z0):
    dx = x - x0
    dy = y - y0
    dz = z - z0
    d = np.sqrt(dx**2 + dy**2 + dz**2)
#     print(len(dx))
    return d

def min_distance(x, y, z, P, precision=5):
    # compute distance
    d = distance_3d(x, y, z, P[0], P[1], P[2])
    d = np.round(d, precision)
    # find the minima
    glob_min_idxs = np.argwhere(d==np.min(d)).ravel()
    return glob_min_idxs, d



from tqdm import tqdm
contour_white_copy = np.zeros((256,256,256),dtype='uint8')
distance_white_mask_loc={}
for i in tqdm(locations_white_contour_mask):
    P = (i[0],i[1],i[2])
    d = distance_3d(x, y, z, P[0],P[1],P[2])
    d = np.round(d, 5)
    glob_min_idxs = np.argwhere(d==np.min(d)).ravel()
    distance_white_mask_loc[P] = min(d)
    contour_white_copy[P[0]][P[1]][P[2]]=min(d)


df_thickness = pd.DataFrame.from_dict(contour_white_copy,orient='index',columns=['Distance']).reset_index()
df_thickness.to_csv('thickness_on_white_contour.csv')


x = np.array([locations_white_contour_mask[i][0] for i in range(len(locations_white_contour_mask))])
y= np.array([locations_white_contour_mask[i][1] for i in range(len(locations_white_contour_mask))])
z= np.array([locations_white_contour_mask[i][2] for i in range(len(locations_white_contour_mask))])


grey_copy = np.zeros((256,256,256),dtype='uint8')
distance_grey_mask_loc={}
for i in tqdm(locations_grey_mask):
    P = (i[0],i[1],i[2])
    min_idx, d = min_distance(x, y, z, P)
    nearest_point_on_grey = (list(x[min_idx])[0],list(y[min_idx])[0],list(z[min_idx])[0])
    
    distance_grey_mask_loc[P] = contour_white_copy[nearest_point_on_grey[0]][nearest_point_on_grey[1]][nearest_point_on_grey[2]]
    grey_copy[P[0]][P[1]][P[2]]=contour_white_copy[nearest_point_on_grey[0]][nearest_point_on_grey[1]][nearest_point_on_grey[2]]
  

df_thickness = pd.DataFrame.from_dict(grey_copy,orient='index',columns=['Distance']).reset_index()
df_thickness.to_csv('thickness_on_grey_mask.csv')


# Phase 3 tuning

import matplotlib
from matplotlib import pylab as plt
import nibabel as nib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skimage.io import imread, imshow
from skimage.color import rgb2gray
from skimage.morphology import (erosion, dilation, closing, opening,
                                area_closing, area_opening)
from skimage.measure import label, regionprops, regionprops_table
from nipype.interfaces.ants.segmentation import BrainExtraction
import nibabel as nib
from nilearn import plotting


thickness_map_1 = nib.load('thickness-in-volume.nii').get_fdata()
thickness_map1 = nib.load('thickness-in-volume.nii')


thickness_map_2 = nib.load('Thickness_map2.nii').get_fdata()
thickness_map2 = nib.load('Thickness_map2.nii')
    
  
from tqdm import tqdm
locations_thickness_map_1 = []
for x,x1 in tqdm(enumerate(thickness_map_1)):
    for y,y1 in enumerate(x1):
        for z,z1 in enumerate(x1):
            if thickness_map_1[x][y][z]!=0.:
                locations_thickness_map_1.append([x,y,z])
                
locations_thickness_map_2 = []
for x,x1 in tqdm(enumerate(thickness_map_2)):
    for y,y1 in enumerate(x1):
        for z,z1 in enumerate(x1):
            if thickness_map_2[x][y][z]!=0.:
                locations_thickness_map_2.append([x,y,z])

from tqdm import tqdm

thickness_map_withCSL_copy = np.zeros(shape=(256,256,256))


for i in tqdm(locations_thickness_map_2):
    x=i[0]
    y=i[1]
    z=i[2]
    if thickness_map_1[x][y][z] ==0.:
        thickness_map_withCSL_copy[x][y][z] = np.round(thickness_map_2[x][y][z],3)
    else:
        thickness_map_withCSL_copy[x][y][z] = np.round(((thickness_map_1[x][y][z]+thickness_map_2[x][y][z]))/2,3)


# out results
plt.imshow(thickness_map_withCSL_copy[:,120,:])
plt.colorbar()


Thickness_map2 = nib.Nifti1Image(thickness_map_withCSL_copy, thickness_map1.affine)


nib.save(Thickness_map2, 'Thickness_map_withCFL.nii')
np.unique(thickness_map_tuned_withCSL_copy)



thickness_map_tuned_withoutCSL_copy = np.zeros(shape=(256,256,256))


for i in tqdm(locations_thickness_map_2):
    x=i[0]
    y=i[1]
    z=i[2]
    if thickness_map_1[x][y][z] ==0.:
        thickness_map_tuned_withoutCSL_copy[x][y][z] = 0.
    else:
        thickness_map_tuned_withoutCSL_copy[x][y][z] = = np.round(((thickness_map_1[x][y][z]+thickness_map_2[x][y][z]))/2,3)

# out results
plt.imshow(thickness_map_tuned_withoutCSL_copy[:,120,:])
plt.colorbar()


Thickness_map2 = nib.Nifti1Image(thickness_map_tuned_withoutCSL_copy, thickness_map1.affine)
nib.save(Thickness_map2, 'Thickness_map_tuned_withoutCFL.nii')